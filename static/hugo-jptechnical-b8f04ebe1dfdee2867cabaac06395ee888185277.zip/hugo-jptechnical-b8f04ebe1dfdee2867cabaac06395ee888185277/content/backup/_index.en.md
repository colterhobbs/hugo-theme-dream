---
title: "Backup & Data Protection"
date: 2021-04-23
icon: "ti-harddrives"

description: "`Have you ever verified your backup?`  If the answer
is “NO”, then you probably don’t have a backup. Seriously...  Sleep easy, knowing
you saw with your own eyes that the last backup was good."

type : "docs"
---
# Backup & Data Protection

Have you ever verified your backup? 

If the answer is “NO”, then you probably don’t have a backup.. Seriously.

Sleep easy, knowing you saw with your own eyes that the last backup was good.
